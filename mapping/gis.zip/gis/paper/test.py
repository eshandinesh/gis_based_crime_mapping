l=[20,24,23,21]
print(min(l))