#from HOTSPOT import *
#env = envelop(filepath="C:\Users\Hp\Desktop\pol\ONEFEATLIST\ONEFEATLIST.shp")
#dictionary_1= main(env, gridHeight=0.005, gridWidth=0.005)

import math
import ogr




