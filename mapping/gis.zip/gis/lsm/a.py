import ogr
import gdal
import osr
import osgeo
import os, os.path, shutil
import osgeo.ogr
import osgeo.osr
from osgeo import osr
import osgeo.ogr as ogr
import osgeo.osr as osr
from gdalconst import *
import pygeoprocessing as pg
import csv
from vector.write import *
from osgeo import ogr
import numpy as np
from raster.basic_function import *

path=mosiac()
reading_raster_band(raster_path=path)
#rpath=reclassify_raster(path,target_rasterPath=None)







